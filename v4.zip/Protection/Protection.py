from Database import db, DatetimeFormat
from datetime import datetime ,timedelta
from Database import ColumnData

packetScore ={}
datetimeFormat = "%Y-%m-%d-%H-%M-%S"
def Protection(ip,pack):
	return {'ipBan':False,'inGameBan':False}
#	user = SupProtectioniP(ip)
#	pk = [47002,47001]
#	now = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
#	nowIP = datetime.strptime(now, "%Y-%m-%d-%H-%M-%S")
#	CAM = packetScore[ip]['CAM']
#	ASM = packetScore[ip]['ASM']
#	banInGame = False
#	if user:
#		if pack in pk:
#			if pack == 47001:
#				if (nowIP - CAM).total_seconds() <= 10:
#					packetScore[ip]['warns'] += 1
#			elif pack == 47002:
#				if (nowIP - ASM).total_seconds() <= 10:
#					packetScore[ip]['warns'] += 1
#					if packetScore[ip]['warns'] >= 3:
#						banInGame = True
#		if packetScore[ip]['warns'] >= 3:
#			packetScore[ip]['ban'] = True
#	if pack == 47001:
# 	   packetScore[ip]['CAM'] = nowIP
#	elif pack == 47002:
#		packetScore[ip]['ASM'] = nowIP
#	return {'ipBan':packetScore[ip]['ban'],'inGameBan':banInGame}
			
			
def SupProtectioniP(us:str):
	now = datetime.now().strftime(datetimeFormat)
	nowIP = datetime.strptime(now, datetimeFormat)
	if packetScore.get(us) is not None:
		return True
	else:
		packetScore[us] = {'score':1,'ban':False,'warns':0,'CAM':nowIP,'ASM':nowIP}
		return False
		
	
def CompareClickTime(token: str, clicks: int):
	#now = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
	now = datetime.now()
	lastClickStr: str = db.ReadColumn(token, ColumnData.LastClickTime)
	lastClick = datetime.strptime(lastClickStr, datetimeFormat)
	warn = False
	ltd = False
	#print(nowT > playerT,(nowT - playerT).total_seconds() < 3,(nowT - playerT).total_seconds())
	if now > lastClick and (now - lastClick).total_seconds() < 3:
		warn = True
	if clicks < 0 or clicks > 85:
		warn = True
		ltd = True

	if warn:
		db.AddToColumn(token, ColumnData.Warn, 1)

	isCheater = False
	if db.ReadColumn(token, ColumnData.Warn) >= 3:
		isCheater = True
		db.SetColumn(token, ColumnData.Banned, 1)

	db.SetColumn(token, ColumnData.LastClickTime, now.strftime(datetimeFormat))
	return {'ban': isCheater,'canContinue': ltd}
	
def DailyReward(time:str):
	now = datetime.now()
	lastClaim = datetime.strptime(time, datetimeFormat)
	if now > lastClaim:
		return True
	else:
		False

def RewardTime(time:str):
	now = datetime.now()
	lastClaim = datetime.strptime(time, datetimeFormat)
	
	response:tuple
	if now > lastClaim:
		response = (now > lastClaim, str(lastClaim - now))
	else:
		info = str(lastClaim - now).split(".")[0].split(":")
		h:str = info[0]
		m:str = info[1]
		s:str = info[2]
		info = f"Осталось:\n{h}ч. {m}м." if int(h) > 0 else f"Осталось:\n{m}м. {s}сек." if int(h) <= 0 and int(m) > 0 else f"Осталось:\n{s}сек." if int(m) <= 0 and int(s) > 0 else "Осталось:\n{s}сек."
		response = (now > lastClaim, info)

	return response