from Protection.Protection import GameProtection
from Database.dbm import DB
import json

db = DB()

class AddScore:
    def __init__(self, client):
        self.client = client
        
    def process(self,data):
        try:
     	   data = json.loads(data.decode('utf-8'))
     	   if data.get('tag') is not None and data.get('score') is not None:
     	   	prot = GameProtection(data['tag'],data['score'] - db.ReadScore(data['tag']))
     	   	if prot['ban']:
     	   		return str({"subpack":47096,"detail":"ban"})
     	   	elif prot['ltd']:
     	   		db.AddClick(data['tag'],1)
     	   		return str({"subpack":47069})
     	   	else:
     	   		db.AddClick(data['tag'],data['score'] - db.ReadScore(data['tag']))
     	   		return str({"subpack":47069})
     	   else:
     	   	return str({"subpack":47096,"detail":"Invalid JSON"})
        except Exception as e:
        	print(e)
        	return str({"subpack":47096,"detail":"Invalid JSON"})