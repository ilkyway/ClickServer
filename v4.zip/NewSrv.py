import socket, asyncio
from Packets.Messaging import packets
from Packets.Decorator import Decorator

async def handle_client(player:socket):
    response = await Decorator().Processor(player)
    player.send(response)
    

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(("0.0.0.0", 6996))
server_socket.listen(5)

print("Сервер встал")

while True:
    client_socket, client_address = server_socket.accept()
    asyncio.run(handle_client(client_socket))
    #client_socket.close()