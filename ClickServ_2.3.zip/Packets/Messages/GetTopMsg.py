from Database.dbm import DB

db = DB()

class GetTop:

    def __init__(self, client):
        self.client = client
    
    def process(self,data):
    	top = db.TopBoard()
    	resp={
    		"subpack":47069,
  	  	"p1":"-",
    		"p2":"-",
    		"p3":"-",
    		"p4":"-",
    		"p5":"-",
    		"p6":"-",
    		"p7":"-",
    		"p8":"-",
    		"p9":"-",
    		"p10":"-"
    	}
    	for pos in range(0,len(top)):
    		resp[f"p{pos+1}"] = {"nick":top[pos][0] , "clicks": top[pos][1] , "tag":top[pos][2]}
    		
    	return str(resp)