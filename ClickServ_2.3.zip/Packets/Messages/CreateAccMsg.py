from Database.dbm import DB
from Protection.Protection import Protection
import json

db = DB()

class CreateAcc:

    def __init__(self, client):
        self.client = client
    
    def process(self,data):
    	if Protection(self.client[0],47001)['ipBan']:
    		return str({"subpack":47096,"detail":"ban"})
    	else:
    		try:
    			data = json.loads(data.decode('utf-8'))
    			nick = None
    			if data.get('nick') is not None:
    				nick = data['nick']
    				if len(nick) < 3:
    					return str({"subpack":47096,"detail":"Нужно большe 3 символов"})
    				elif len(nick) > 16:
    					return str({"subpack":47096,"detail":"Небольше 16 символов"})
    				elif " " in nick:
    					return str({"subpack":47096,"detail":"Ник должен быть без пробелов"})
    				elif "\n" in nick:
    					return str({"subpack":47096,"detail":"Ник должен быть в одну строку"})
    				else:
    					acc = db.createProfile(data['nick'])
    					return str({"subpack":47069,"tag":acc[0],"token":acc[1]})
    			else:
    				return str({"subpack":47096,"detail":"Nickname is null"})
    		except Exception as e:
    			print(e)
    			return str({"subpack":47096,"detail":"Invalid JSON"})