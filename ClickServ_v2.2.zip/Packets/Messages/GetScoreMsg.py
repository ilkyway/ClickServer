from Database.dbm import DB
import json

db = DB()

class GetScore:
	def __init__(self, client):
	      self.client = client
       
	def process(self,data):
		try:
			data = json.loads(data.decode('utf-8'))
			if data.get('tag') is not None:
				if db.isUserExist(data['tag']):
					if db.ReadBan(data['tag']):
						return str({"subpack":47096,"detail":"ban"})
					else:
						return str({"subpack":47069,'score':db.ReadScore(data['tag'])})
				else:
					return str({"subpack":47096,"detail":"Non-existent account"})
			else:
				return str({"subpack":47096,"detail":"Invalid JSON"})
		except:
			return str({"subpack":47096,"detail":"Invalid JSON"})