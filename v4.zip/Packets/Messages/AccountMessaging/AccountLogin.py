from socket import socket
from DataTypes.Player import Player
from DataTypes.ServerCode import ServerCode
from Database import db
import json

class AccountLogin:
    def __init__(self, client: socket):
        self.client = client
		
    def Process(self, data: dict) -> tuple[ServerCode, dict or None] or dict:
        token: str or None = data.get("token")
        player: Player or None = db.ReadProfile(token=token)
        if (player is None): return

        if (player.isBanned):
            return (ServerCode.AccessDenied, {"ban": "Хуй. Нужно добавить в дб строчку с описанием бана."})
        
        return {"subpack":ServerCode.Success}
		
        