from DataTypes.ServerCode import ServerCode
from Protection.Protection import RewardTime
from Database import db, ColumnData
import random

class ChestTime:
    def __init__(self, client):
        self.client = client
        
    def Process(self,data):
        token: str | None = data.get('token')
        
        if token is None:
            return None

        lastReward: str = db.ReadColumn(token, ColumnData.DailyChest)
        
        timeLine = RewardTime(lastReward)
        
        canClaim = 1 if timeLine[0] else 0
        
        timeInfo = timeLine[1]
        
        return {
    	"subpack":ServerCode.Success,
    	"type":canClaim,
    	"data":timeInfo
        }