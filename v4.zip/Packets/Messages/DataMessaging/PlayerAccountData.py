from Database import db, ColumnData
from DataTypes.ServerCode import ServerCode
from Protection.Protection import DailyReward
import json

class GetAccountData:
	def __init__(self, client):
		self.client = client
    
	def Process(self, data: dict):
		tag: str | None = data.get('tag')
		if (tag is None): return None

		if (not db.IsUserExist(tag)): return {"subpack": ServerCode.InvalidUser}

		# profile data return
		profile = db.ReadProfile(tag=tag)
		if (profile is None): return None

		daily = 11 if DailyReward(profile.dailyChest) else 10

		return {
			"subpack": ServerCode.Success,
			"nick": profile.nickname,
			"clicks": profile.clicksCount,
			"avatar": profile.avatarID,
			"skin": profile.skinID,
			"coins": profile.coins,
			"daily":daily
		}
	