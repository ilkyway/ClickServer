import sqlite3

def Clear():
	connection = sqlite3.connect('users.db')
	cursor = connection.cursor()
	cursor.execute('DELETE FROM players')
	connection.commit()
	connection.close()
