from Database.dbm import DB
import json

db = DB()

class CheckAcc:
    def __init__(self, client):
        self.client = client
    def process(self,data):
        data = json.loads(data.decode('utf-8'))
        try:
        	if data.get('tag') is not None:
        		if db.isUserExist(data['tag']):
        			if db.ReadBan(data['tag']):
        				return str({"subpack":47096,"detail":"ban"})
        			else:
        				return str({"subpack":47069})
        		else:
        			return str({"subpack":47096,"detail":"This is a deleted account"})
        	else:
        		return str({"subpack":47096,"detail":"Invalid JSON"})
        except Exception as e:
        	return str({"subpack":47096,"detail":"Invalid JSON"})
        	print(e)
        	pass