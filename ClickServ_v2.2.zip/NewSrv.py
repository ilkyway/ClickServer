import socket
from Packets.Messaging import packets

def buildResponse(data):
	response_value = 1
	response_header = bytearray(7)
	response_header[:2] = (47047).to_bytes(2, 'big')
	response_header[2:5] = len(data.encode('utf-8')).to_bytes(3, 'big')
	response_data = data.encode('utf-8')
	return response_header + response_data
	

def handle_client(client_socket):
    while True:
        try:
            header = client_socket.recv(7)
            if len(header) > 0:
                packet_id = int.from_bytes(header[:2], 'big')
                length = int.from_bytes(header[2:5], 'big')
                data = client_socket.recv(length)

                if packets.get(packet_id) is not None:
                	print(f"Packet ID - {packet_id} from {client_socket.getpeername()}")
                	client_socket.send(buildResponse(packets[packet_id](client_socket.getpeername()).process(data)))
                else:
                	print(f"Undiferend Packet ID - {packet_id} from {client_socket.getpeername()}")
                	client_socket.send(buildResponse(str({"subpack":47096,"detail":"Incorrect packet id"})))
                break

        except Exception as e:
            print(e)
            client_socket.send(buildResponse(str({"subpack":47096,"detail":"Server error"})))
            break

    client_socket.close()

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(("127.0.0.1", 6996))
server_socket.listen(5)

print("Сервер встал")

while True:
    client_socket, client_address = server_socket.accept()
    handle_client(client_socket)