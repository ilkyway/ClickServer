from enum import Enum

class Code:
    Success = 47069
    Fail = 47096
    AccessDenied = 66666
    InvalidUser = 696969
    
ServerCode = Code()