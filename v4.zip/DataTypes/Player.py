
class Player:
    def __init__(self, nickname: str = "", isBanned: bool = False, clicks: int = 0, avatarID: int = 0, skinID: int = 0, coins: int = 0, dailyChest: str = "") -> None:
        # Параметры
        self.nickname = nickname
        self.isBanned = isBanned

        self.avatarID = avatarID
        self.skinID = skinID

        # Статистика
        self.coins = coins
        self.clicksCount = clicks
        self.dailyChest = dailyChest

