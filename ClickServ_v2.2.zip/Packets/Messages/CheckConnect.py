class CheckConnect:
    def __init__(self, client):
        self.client = client
        
    def process(self,data):
        return str({"subpack":47069})