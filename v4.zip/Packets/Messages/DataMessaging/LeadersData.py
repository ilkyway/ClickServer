from Database import db, ColumnData
from DataTypes.ServerCode import ServerCode

class GetLeadersData:
	def __init__(self, client):
		self.client = client
    
	def Process(self, _: dict):
		top = db.TopBoard()
        
		response={
			"subpack":ServerCode.Success,
			"p1":"-",
			"p2":"-",
			"p3":"-",
			"p4":"-",
			"p5":"-",
			"p6":"-",
			"p7":"-",
			"p8":"-",
			"p9":"-",
			"p10":"-"
    	}

		for pos in range(0,len(top)):
			response[f"p{pos+1}"] = {"nick":top[pos][0] , "clicks": top[pos][1] , "tag":top[pos][2]}
    		
		return response