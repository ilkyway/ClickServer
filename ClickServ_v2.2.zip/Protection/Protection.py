from Database.dbm import DB
from datetime import datetime, timedelta

packetScore ={}

db = DB()

def Protection(ip,pack):
	user = SupProtectioniP(ip)
	pk = [47002,47001]
	now = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
	nowIP = datetime.strptime(now, "%Y-%m-%d-%H-%M-%S")
	CAM = packetScore[ip]['CAM']
	ASM = packetScore[ip]['ASM']
	banInGame = False
	if user:
		if pack in pk:
			if pack == 47001:
				if (nowIP - CAM).total_seconds() <= 10:
					packetScore[ip]['warns'] += 1
			elif pack == 47002:
				if (nowIP - ASM).total_seconds() <= 10:
					packetScore[ip]['warns'] += 1
					if packetScore[ip]['warns'] >= 3:
						banInGame = True
		if packetScore[ip]['warns'] >= 3:
			packetScore[ip]['ban'] = True
	if pack == 47001:
 	   packetScore[ip]['CAM'] = nowIP
	elif pack == 47002:
		packetScore[ip]['ASM'] = nowIP
	return {'ipBan':packetScore[ip]['ban'],'inGameBan':banInGame}
			
			
def SupProtectioniP(us:str):
	now = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
	nowIP = datetime.strptime(now, "%Y-%m-%d-%H-%M-%S")
	if packetScore.get(us) is not None:
		return True
	else:
		packetScore[us] = {'score':1,'ban':False,'warns':0,'CAM':nowIP,'ASM':nowIP}
		return False
		
	
def GameProtection(tag,clicks):
	now = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
	nowT = datetime.strptime(now, "%Y-%m-%d-%H-%M-%S")
	playerT = datetime.strptime(db.ReadTime(tag), "%Y-%m-%d-%H-%M-%S")
	warn = False
	ltd = False
	#print(nowT > playerT,(nowT - playerT).total_seconds() < 3,(nowT - playerT).total_seconds())
	if nowT > playerT and (nowT - playerT).total_seconds() < 3:
		warn = True
	if clicks < 0 or clicks > 185:
		warn = True
		ltd = True
	if warn:
		db.AddWarn(tag)
	if db.ReadWarns(tag) >= 3:
		db.SetBan(tag,1)
	db.SetTime(tag,now)
	return {'ban':db.ReadBan(tag),'ltd':ltd}
	