from socket import socket
import json
from Packets.Messaging import packets

class Decorator:
	
	async def buildResponse(self,data:str) -> str:
		data = str(data)
		response_header = bytearray(7)
		response_header[:2] = (47047).to_bytes(2, 'big')
		response_header[2:5] = len(data.encode('utf-8')).to_bytes(3, 'big')
		response_data = data.encode('utf-8')
		return response_header + response_data
		
	async def Processor(self,player:socket) -> str:
	    while True:
		    try:
			
			    header = player.recv(7)
			    if len(header) > 0:
				    packet_id = int.from_bytes(header[:2], 'big')
				    length = int.from_bytes(header[2:5], 'big')
				    data = player.recv(length)
				
				    if packets.get(packet_id) is not None:
				    	print(f"Packet ID - {packet_id} from {player.getpeername()}")
					
				    	data: dict = json.loads(data.decode('utf-8'))
					
				    	response = await self.buildResponse(packets[packet_id](player.getpeername()).Process(data))
					
				    	return response
				    else:
					
					    print(f"Undiferend Packet ID - {packet_id} from {player.getpeername()}")
					
					    return await self.buildResponse({"subpack":47096,"detail":"Incorrect packet id"})
				    break
					
		    except Exception as e:
			
			    print(e)
			
			    return await self.buildResponse({"subpack":47096,"detail":"Server error"})
			    break