from socket import socket
from Database import db, ColumnData
from DataTypes.ServerCode import ServerCode
import json
from Protection.Protection import Protection
from enum import Enum

class CreateStatus:
	Success = 0
	ShortNickname = 1
	LongNickname = 2
	UnknownCharacters = 4
	MultilineString = 5

class CreateAccount:
	def __init__(self, client: socket):
		self.client = client

	def Process(self, data: dict):
		#if Protection(self.client.getpeername()[0],47001)['ipBan']: 
		#	return {"subpack": ServerCode.AccessDenied}

		nickname: str or None = data.get('nick')
		if (nickname is None): return None

		statusCode: CreateStatus = CreateStatus().Success
		tag = ""
		token = ""

		if len(nickname) < 3:
			statusCode = CreateStatus().ShortNickname

		elif len(nickname) > 16:
			statusCode = CreateStatus().LongNickname

		elif " " in nickname:
			statusCode = CreateStatus().UnknownCharacters

		elif "\n" in nickname: 
			statusCode = CreateStatus().MultilineString

		else:
			tag, token  = db.CreateProfile(nickname)

		return {"subpack": ServerCode.Success, "status": statusCode, "tag": tag, "token":token}