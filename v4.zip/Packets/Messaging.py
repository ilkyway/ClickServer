from Packets.Messages.AccountMessaging.CreateAccount import CreateAccount
from Packets.Messages.DataMessaging.PlayerAccountData import GetAccountData
from Packets.Messages.GameMessaging.StillAlive import StillAliveMessage
from Packets.Messages.GameMessaging.AddScore import UpdateUserScores
from Packets.Messages.DataMessaging.PlayerScoreData import GetPlayerScoreData
from Packets.Messages.DataMessaging.LeadersData import GetLeadersData
from Packets.Messages.AccountMessaging.AccountLogin import AccountLogin
from Packets.Messages.GameMessaging.Daily.TestChestDrop import TestChestDrop
from Packets.Messages.GameMessaging.Daily.ChestTime import ChestTime

packets={
	47001:	CreateAccount,
    47003:	AccountLogin,
	47002:	UpdateUserScores,
	47111:	StillAliveMessage,
	47112:	GetAccountData,
	47666:	GetLeadersData,
	47004:  GetPlayerScoreData,
	47105:  TestChestDrop,
    47106:  ChestTime
}