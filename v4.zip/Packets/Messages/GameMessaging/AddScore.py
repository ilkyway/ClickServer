from Protection.Protection import CompareClickTime
from Database import db, ColumnData
from DataTypes.ServerCode import ServerCode
from Protection.Protection import DailyReward
import json

class UpdateUserScores:
	def __init__(self, client):
		self.client = client
    
	def Process(self, data: dict) -> str | None:
	
		token: str | None = data.get('token')
		score: int | None = data.get('score')
		
		if token is None or score is None:
			return None
		
		db_score: int = db.ReadColumn(token, ColumnData.Score)
		#securityCheck = CompareClickTime(token, score - db_score)
		lastReward: str = db.ReadColumn(token, ColumnData.DailyChest)
		
		daily = 11 if DailyReward(lastReward) else 10
		
		#print(securityCheck)

		# Хуй. Нужно на класс переработать
		#if securityCheck['ban']:
			#return {"subpack": ServerCode.AccessDenied}
		
		# что за название дебильные
		#elif securityCheck["canContinue"]:
			#if (db.AddToColumn(token, ColumnData.Score, 1)):
				#return {"subpack": ServerCode.Success,"daily":daily}

		db.AddClick(token, score - db_score)
		return {"subpack": ServerCode.Success,"daily":daily}