from DataTypes.ServerCode import ServerCode
from Database import db, ColumnData
from Protection.Protection import RewardTime
import random
from datetime import datetime, timedelta

class TestChestDrop:
    def __init__(self, client):
        self.client = client
        
    def Process(self,data):
    	token: str | None = data.get('token')
    	
    	if token is None:
            return None
            
    	lastReward: str = db.ReadColumn(token, ColumnData.DailyChest)
    	
    	timeLine = RewardTime(lastReward)
    	
    	resp:dict
    	
    	print(timeLine)
    	
    	if timeLine[0]:
    		drop = random.randint(20,150)
    		
    		db.AddToColumn(token,ColumnData.Coins,drop)
    		
    		rewardDate = datetime.strptime(datetime.now().strftime("%Y-%m-%d-%H-%M-%S"), "%Y-%m-%d-%H-%M-%S") + timedelta(hours=12)
    		rewardDate = rewardDate.strftime("%Y-%m-%d-%H-%M-%S")
		
    		db.SetColumn(token,ColumnData.DailyChest,rewardDate)
    		
    		resp = {
    			"subpack":ServerCode.Success,
    			"type":1,
    			"data":drop}
    			
    	else:
    		resp = {"subpack":ServerCode.Fail,"detail":"The time has not come"}
    	
    	
    	return resp