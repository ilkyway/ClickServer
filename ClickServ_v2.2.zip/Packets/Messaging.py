from Packets.Messages.CreateAccMsg import CreateAcc
from Packets.Messages.CheckAccMsg import CheckAcc
from Packets.Messages.CheckConnect import CheckConnect
from Packets.Messages.AddScoreMsg import AddScore
from Packets.Messages.GetScoreMsg import GetScore
from Packets.Messages.GetTopMsg import GetTop

packets={
	47001:CreateAcc,
	47002:AddScore,
	47111:CheckConnect,
	47112:CheckAcc,
	47474:GetScore,
	47666:GetTop
}