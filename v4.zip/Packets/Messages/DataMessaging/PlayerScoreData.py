from Database import db, ColumnData
from DataTypes.ServerCode import ServerCode
import json

class GetPlayerScoreData:
	def __init__(self, client):
		self.client = client
    
	def Process(self, data: dict):
		token: str | None = data.get('token')
		if (token is None): return None

		#if (not data_instance.IsUserExist(token)): return None
		
		return {"subpack":ServerCode.Success, 'score': db.ReadColumn(token, ColumnData.Score)}