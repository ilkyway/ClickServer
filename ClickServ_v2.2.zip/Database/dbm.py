import sqlite3 as sql
import random
import string
from datetime import datetime, timedelta

class DB:
	def createProfile(self,nick):
		tag = ''.join(random.choices(string.ascii_lowercase + string.digits, k=7))
		self.conn = sql.connect("Database/users.db")
		
		dt = datetime.strptime(datetime.now().strftime("%Y-%m-%d-%H-%M-%S"), "%Y-%m-%d-%H-%M-%S") - timedelta(seconds=15)
		dt = dt.strftime("%Y-%m-%d-%H-%M-%S")
		
		self.cur = self.conn.cursor()
		var = tag, nick,0,0,0, str(dt)
		self.cur.execute("INSERT INTO players VALUES (?,?,?,?,?,?)", var)
		self.conn.commit()
		self.conn.close()
		return tag
		
	def TopBoard(self):
	   self.conn = sql.connect("Database/users.db")
	   self.cur = self.conn.cursor()
	   self.cur.execute("""
        SELECT nick as nick, clicks
        FROM players
        WHERE ban != 1
        ORDER BY clicks DESC
        LIMIT 10
    """)
	   fetch = self.cur.fetchall()
	   return fetch
	   
	def ReadScore(self,tag):
		self.conn = sql.connect("Database/users.db")
		self.cur = self.conn.cursor()
		try:
			self.cur.execute(f'SELECT clicks FROM players WHERE tag=?', (tag,))
			fetch = self.cur.fetchall()
			return fetch[0][0]
		except (sql.OperationalError, IndexError) as e:
			return 0
			print(e)
			
	def AddClick(self, tag,clicks):
		self.conn = sql.connect("Database/users.db")
		self.cur = self.conn.cursor()
		self.cur.execute(f"UPDATE players SET clicks = clicks + ? WHERE tag=?",(clicks,tag))
		self.conn.commit()
		self.conn.close()
		
	def isUserExist(self, tag):
		self.conn = sql.connect("Database/users.db")
		self.cur = self.conn.cursor()
		try:
			self.cur.execute(f'SELECT * FROM players WHERE tag=?', (tag,))
			fetch = self.cur.fetchall()
			if len(fetch) > 0:
				return True
			self.conn.close()
		except (sql.OperationalError, IndexError) as e:
			print(e)
			return False
			
	def ReadBan(self,tag):
		self.conn = sql.connect("Database/users.db")
		self.cur = self.conn.cursor()
		try:
			self.cur.execute(f'SELECT ban FROM players WHERE tag=?', (tag,))
			fetch = self.cur.fetchall()
			if fetch[0][0] == 1:
				return True
			else:
				return False
		except (sql.OperationalError, IndexError) as e:
			return 0
			print(e)
			
	def ReadTime(self,tag):
		self.conn = sql.connect("Database/users.db")
		self.cur = self.conn.cursor()
		try:
			self.cur.execute(f'SELECT time FROM players WHERE tag=?', (tag,))
			fetch = self.cur.fetchall()
			return fetch[0][0]
		except (sql.OperationalError, IndexError) as e:
			return 0
			print(e)
			
	def ReadWarns(self,tag):
		self.conn = sql.connect("Database/users.db")
		self.cur = self.conn.cursor()
		try:
			self.cur.execute(f'SELECT warns FROM players WHERE tag=?', (tag,))
			fetch = self.cur.fetchall()
			return fetch[0][0]
		except (sql.OperationalError, IndexError) as e:
			return 0
			print(e)
			
	def AddWarn(self, tag):
		self.conn = sql.connect("Database/users.db")
		self.cur = self.conn.cursor()
		self.cur.execute(f"UPDATE players SET warns = warns + 1 WHERE tag=?",(tag,))
		self.conn.commit()
		self.conn.close()
		
	def SetBan(self, tag,ban):
		self.conn = sql.connect("Database/users.db")
		self.cur = self.conn.cursor()
		self.cur.execute(f"UPDATE players SET ban = ? WHERE tag=?",(ban,tag))
		self.conn.commit()
		self.conn.close()
		
	def SetTime(self, tag,time):
		self.conn = sql.connect("Database/users.db")
		self.cur = self.conn.cursor()
		self.cur.execute(f"UPDATE players SET time = ? WHERE tag=?",(time,tag))
		self.conn.commit()
		self.conn.close()