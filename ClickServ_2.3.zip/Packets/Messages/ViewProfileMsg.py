from Database.dbm import DB
import json

db = DB()

class ViewProfile:
    def __init__(self, client):
        self.client = client
        
    def process(self,data):
    	data = json.loads(data.decode('utf-8'))
    	try:
    		profile = db.ReadProfile(data['tag'])
    		return str({"subpack":47069,"nick":profile[0],"clicks":profile[1],"avatar":profile[2],"skin":profile[3]})
    	except Exception as e:
    		print(e)
    		return str({"subpack":47096,"detail":"Invalid JSON"})