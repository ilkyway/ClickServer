import sqlite3 as sql
import random
import string
from datetime import datetime, timedelta
import traceback

from enum import Enum

from DataTypes.Player import Player

class ColumnData(Enum):
	Warn = "warns"
	CreationDate = "time"
	Score = "clicks"
	Banned = "ban"
	LastClickTime = "time"
	AvatarID = "avatarID"
	SkinID = "skinID"
	Coins = "coins"
	DailyChest = "dailyChest"

class DatabaseDataTypes(Enum):
	integer = "INTEGER"
	string = "TEXT"

DatetimeFormat = "%Y-%m-%d-%H-%M-%S"

class DB:
	def __init__(self) -> None:
		self.connection = sql.connect("Database/users.db", check_same_thread=False)
		self.cursor = self.connection.cursor()

	def __del__(self) -> None:
		self.connection.close()

	############################### Data Update ##################################

	def AddTableProperty(self, table: str, name: str, type: DatabaseDataTypes, default: any = None):
		message = f"ALTER TABLE {table} ADD {name} {type.value}"
		if (default is not None):
			message += f" DEFAULT ({default})"

		self.cursor.execute(message)

	def AddPlayerProperty(self, name: str, type: DatabaseDataTypes, default: any = None):
		self.AddTableProperty("players", name, type, default)

	############################### Data Process ##################################

	def CreateProfile(self,nick):
		tag = ''.join(random.choices(string.ascii_lowercase + string.digits, k=7))
		
		# переделывай
		createDate = datetime.strptime(datetime.now().strftime("%Y-%m-%d-%H-%M-%S"), "%Y-%m-%d-%H-%M-%S") - timedelta(seconds=15)
		createDate = createDate.strftime("%Y-%m-%d-%H-%M-%S")
		
		rewardDate = datetime.strptime(datetime.now().strftime("%Y-%m-%d-%H-%M-%S"), "%Y-%m-%d-%H-%M-%S") - timedelta(hours=25)
		rewardDate = rewardDate.strftime("%Y-%m-%d-%H-%M-%S")

		token = ''.join(random.choices(string.ascii_lowercase + string.digits, k=15))

		# было бы неплохо добавить типизацию этому всему
		playerCreationData = tag, nick, 0, 0, 0, str(createDate), 0,0,token,0,rewardDate
		self.cursor.execute("INSERT INTO players VALUES (?,?,?,?,?,?,?,?,?,?,?)", playerCreationData)

		self.connection.commit()

		return (tag,token)
		
	def TopBoard(self):
		self.cursor.execute("""
        SELECT nick as nick, clicks, tag
        FROM players
        WHERE ban != 1
        ORDER BY clicks DESC
        LIMIT 10
		""")

		return self.cursor.fetchall()
	   
	#def ReadScore(self,tag):
	#	try:
	#		self.cursor.execute('SELECT clicks FROM players WHERE token=?', (tag))
	#		fetch = self.cur.fetchall()
	#		# Загадка от жака фреско: кто?
	#		return fetch[0][0]
	#	except (sql.OperationalError, IndexError) as e:
	#		return 0
			
	def AddClick(self, token, clicks):
		self.cursor.execute(
			"UPDATE players SET clicks = clicks + ? WHERE token=?",
												(clicks,	token)
		)
		self.connection.commit()
		
	def IsUserExist(self, tag):
		try:
			self.cursor.execute(f'SELECT * FROM players WHERE tag=?', (tag, ))
			fetch = self.cursor.fetchall()
			if len(fetch) > 0:
				return True
		except (sql.OperationalError, IndexError) as e:
			print("Database error in UserExist func:")
			print(traceback.print_exc())
			return False

	def ReadColumn(self, token: str, type: ColumnData) -> any or None:
		try:
			self.cursor.execute(f'SELECT {type.value} FROM players WHERE token=? AND ban != 1', (token,))
			fetch = self.cursor.fetchall()

			return fetch[0][0]
		except Exception as err:
			print("Database error in Read func:")
			print(traceback.print_exc())
			return None
			
	def AddToColumn(self, token: str, type: ColumnData, value: str or int) -> bool:
		originalValue = self.ReadColumn(token, type)
		return self.SetColumn(token, type, originalValue + value)
		

	def SetColumn(self, token: str, type: ColumnData, value: int or str) -> bool:
		if (isinstance(value, str)): value = f'"{value}"'

		try:
			self.cursor.execute(f"UPDATE players SET {type.value} = {value} WHERE token=? AND ban != 1", (token,))
				
		except (sql.OperationalError) as err:
			print("Database error in Write func:")
			print(traceback.print_exc())
			return False
	
		finally:
			return True
		
	def ReadProfile(self, tag: str = None, token: str = None) -> Player or None:
		try:
			self.cursor.execute(f'SELECT nick, ban, clicks, avatarID, skinID, coins, dailyChest FROM players WHERE {"tag" if tag is not None else "token"}=?', (tag if token is None else token,))
			fetch = self.cursor.fetchall()

			return Player(*fetch[0])
		
		except Exception as e:
			print("Database error in ReadProfile func:")
			print(traceback.print_exc())
			return None
			

db = DB()