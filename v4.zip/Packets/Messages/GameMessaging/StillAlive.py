from DataTypes.ServerCode import ServerCode

class StillAliveMessage:
    def __init__(self, client):
        self.client = client
        
    def Process(self, _: dict):
        return str({"subpack":ServerCode.Success})